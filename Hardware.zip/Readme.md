1. .epro file is the PCB project. To use it, open https://pro.easyeda.com/editor and click File/ import as esayeda (professional) version.
2. All the datasheets can be found in both local folder or lcsc.com, expect for MCU, it is Teensy 4.1.
3. New version of evaluation board is in development.
